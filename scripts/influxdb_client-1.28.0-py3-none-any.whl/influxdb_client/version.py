"""Version of the Client that is used in User-Agent header."""

CLIENT_VERSION = '1.28.0'
